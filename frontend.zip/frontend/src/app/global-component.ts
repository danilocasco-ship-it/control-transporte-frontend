export const GlobalComponent = {
  // Api Calling
  API_URL: "https://api-node.themesbrand.website/",
  headerToken: { Authorization: `Bearer ${sessionStorage.getItem("token")}` },

  // Auth Api
   // AUTH_API: "https://api-node.themesbrand.website/auth/",
  AUTH_API: "http://localhost:8097/",
  //AUTH_API: "https://172.16.0.16:8097/",
  // Products Api
  product: "apps/product",
  productDelete: "apps/product/",

  // Orders Api
  order: "apps/order",
  orderId: "apps/order/",

  // Customers Api
  customer: "apps/customer",
};

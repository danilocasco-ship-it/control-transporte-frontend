export const environment = {
  production: true,
  apiUrl: 'http://192.168.21.13:8097/',
  portalAuth: {
    urlAppLogin: 'http://192.168.21.13:8066',
    urlApiLogin: 'http://192.168.21.13:8065/api',
    urlApiModulo: 'http://192.168.21.13:8097/api'
  }
};

export const environment = {
  production: false,
  apiUrl: 'http://localhost:8097/',
  portalAuth: {
    urlAppLogin: 'http://localhost:4201',
    urlApiLogin: 'http://localhost:8080/api',
    urlApiModulo: 'http://localhost:8097/api'
  }
};
